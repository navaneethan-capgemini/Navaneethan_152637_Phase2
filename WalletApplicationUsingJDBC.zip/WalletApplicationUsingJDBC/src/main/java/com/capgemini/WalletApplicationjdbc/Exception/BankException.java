package com.capgemini.WalletApplicationjdbc.Exception;

@SuppressWarnings("serial")
public class BankException extends Exception {
public BankException(String msg) {
	super(msg);
}
}
